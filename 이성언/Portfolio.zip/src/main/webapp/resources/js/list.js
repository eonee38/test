/**
 * 
 */

$(document).ready(function(){ // 게시글 검색 기능 구현 시 id부여하고 그 생성자를 여기에 써주기!
	// 검색버튼을 클릭하면
	//$("input[type='button']").on("click",function(){
		// pageNum에 1을 초기화
		//$("input[name='pageNum']").val("1");
		// form태그를 submit
		//$("#searchForm").submit();
	//})
})